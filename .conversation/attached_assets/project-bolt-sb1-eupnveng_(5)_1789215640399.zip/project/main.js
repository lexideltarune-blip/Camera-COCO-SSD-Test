import * as tf from '@tensorflow/tfjs';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import './style.css';

const video = document.querySelector('#camera-video');
const canvas = document.querySelector('#camera-canvas');
const context = canvas.getContext('2d', { alpha: true });
const relationshipText = document.querySelector('#relationship-text');
const cameraStatus = document.querySelector('#camera-status');
const statusDot = document.querySelector('#status-dot');
const cameraButton = document.querySelector('#camera-button');
const newTabButton = document.querySelector('#new-tab-button');
const permissionWarning = document.querySelector('#permission-warning');

let stream = null;
let model = null;
let detectorTimer = 0;
let detecting = false;
const inIframe = window.self !== window.top;

function setStatus(message, tone = 'amber') {
  cameraStatus.textContent = message;
  statusDot.className = `h-2 w-2 shrink-0 rounded-full bg-${tone}-400`;
}

function showPermissionWarning() {
  permissionWarning.classList.remove('hidden');
}

function hidePermissionWarning() {
  permissionWarning.classList.add('hidden');
}

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}

function center(box) {
  return { x: box[0] + box[2] / 2, y: box[1] + box[3] / 2 };
}

function relationship(first, second) {
  const firstCenter = center(first.bbox);
  const secondCenter = center(second.bbox);
  const firstName = first.class;
  const secondName = second.class;

  const verticalGap = Math.abs(firstCenter.y - secondCenter.y);
  const verticalAlignmentThreshold = Math.min(first.bbox[3], second.bbox[3]) * 0.35;

  if (verticalGap > verticalAlignmentThreshold && firstCenter.y < secondCenter.y) {
    return `The ${firstName} is on the top of the ${secondName}`;
  }
  if (verticalGap > verticalAlignmentThreshold && firstCenter.y > secondCenter.y) {
    return `The ${firstName} is at the bottom of the ${secondName}`;
  }
  if (firstCenter.x < secondCenter.x) {
    return `The ${firstName} is beside the ${secondName} (Left)`;
  }
  if (firstCenter.x > secondCenter.x) {
    return `The ${firstName} is beside the ${secondName} (Right)`;
  }
  return '';
}

async function detectObjects() {
  if (!model || !stream || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA || detecting) return;
  detecting = true;
  try {
    const predictions = await model.detect(video, 20, 0.45);
    const objects = predictions.filter((p) => p.score >= 0.55);

    context.clearRect(0, 0, canvas.width, canvas.height);

    const scaleX = canvas.width / video.videoWidth;
    const scaleY = canvas.height / video.videoHeight;
    const scale = Math.max(scaleX, scaleY);
    const offsetX = (canvas.width - video.videoWidth * scale) / 2;
    const offsetY = (canvas.height - video.videoHeight * scale) / 2;

    objects.forEach((obj) => {
      const [bx, by, bw, bh] = obj.bbox;
      const x = bx * scale + offsetX;
      const y = by * scale + offsetY;
      const w = bw * scale;
      const h = bh * scale;

      context.strokeStyle = '#34d399';
      context.lineWidth = 2;
      context.strokeRect(x, y, w, h);

      const label = `${obj.class} ${Math.round(obj.score * 100)}%`;
      context.font = '13px monospace';
      const textWidth = context.measureText(label).width;
      context.fillStyle = 'rgba(2,6,23,0.75)';
      context.fillRect(x, y - 20, textWidth + 8, 20);
      context.fillStyle = '#34d399';
      context.fillText(label, x + 4, y - 5);
    });

    relationshipText.textContent = objects.length === 2 ? relationship(objects[0], objects[1]) : '';
  } catch {
    setStatus('Scene analysis paused. Retrying automatically.', 'amber');
  } finally {
    detecting = false;
  }
}

function scheduleDetection() {
  window.clearTimeout(detectorTimer);
  detectorTimer = window.setTimeout(async () => {
    await detectObjects();
    scheduleDetection();
  }, 350);
}

async function loadTracker() {
  try {
    await tf.ready();
    model = await cocoSsd.load({ base: 'lite_mobilenet_v2' });
    setStatus('Camera live. Tracking two-object relationships.', 'emerald');
    scheduleDetection();
  } catch {
    setStatus('Camera live, but scene tracking could not start.', 'red');
  }
}

function waitForMetadata() {
  if (video.readyState >= HTMLMediaElement.HAVE_METADATA) return Promise.resolve();
  return new Promise((resolve) => video.addEventListener('loadedmetadata', resolve, { once: true }));
}

async function requestCameraPermission() {
  if (window.Capacitor) {
    const { Camera } = await import('@capacitor/camera');
    const result = await Camera.requestPermissions({ permissions: ['camera'] });
    if (result.camera !== 'granted') throw new Error('permission-denied');
  }
}

async function startCamera() {
  cameraButton.disabled = true;
  cameraButton.textContent = 'Starting';
  hidePermissionWarning();
  setStatus('Requesting camera access...', 'amber');
  try {
    await requestCameraPermission();
    if (!navigator.mediaDevices?.getUserMedia) throw new Error('unsupported');
    stream?.getTracks().forEach((track) => track.stop());
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false,
    });
    video.srcObject = stream;
    await waitForMetadata();
    await video.play();
    cameraButton.classList.add('hidden');
    newTabButton.classList.add('hidden');
    setStatus('Camera live. Loading scene tracker...', 'emerald');
    if (!model) loadTracker();
  } catch {
    showPermissionWarning();
    const message = inIframe
      ? 'Camera access is blocked by the embedded preview. Open this app in a full browser tab.'
      : 'Camera access was denied or is unavailable. Check permissions and try again.';
    setStatus(message, 'red');
    cameraButton.disabled = false;
    cameraButton.textContent = 'Retry';
    if (inIframe) newTabButton.classList.remove('hidden');
  }
}

cameraButton.addEventListener('click', startCamera);
newTabButton.addEventListener('click', () => window.open(window.location.href, '_blank', 'noopener,noreferrer'));
window.addEventListener('resize', resizeCanvas);
resizeCanvas();
startCamera();
